<?php



class Bootstrap {

    public function getBootstrap(){
        // تحديد المسار الكامل للـ Get_Config.php
        $GLOBAL_URL = "http://" . $_SERVER['HTTP_HOST'] . BASEDIR ;
        
        // تضمين ملف إعدادات الاتصال بقاعدة البيانات
        include_once ($_SERVER['DOCUMENT_ROOT'] . BASEDIR . 'application/config/config.php');
        
        // التأكد من أن الاتصال تم بنجاح
        if (!isset($con)) {
            die("خطأ: الاتصال بقاعدة البيانات غير معرف.");
        }
    }

    public function runBootstrap(){
        $this->getBootstrap(); // تحميل إعدادات الاتصال بقاعدة البيانات
    }

    public function getConnection() {
        global $con;  // إرجاع الاتصال الذي تم تعريفه في config
        return $con;
    }
}




Route::set('', function() {
View::make('Root');
});


Route::set('bootstrap', function() {
View::make('bootstrap');
});







Route::set('builder', function() {
View::make('builder');
});






Route::set('savecode', function() {
View::make('savecode');
});



  

 

 

 

 

 
/*Dashboard/mobile_header*/
Route::set('mobile_header', function() {
View::make('mobile_header');
});



 
/*Admin/atest*/
Route::set('atest', function() {
View::make('Admin/atest');
});

 
/*Dashboard/dtest*/
Route::set('dtest', function() {
View::make('Dashboard/dtest');
});

 
/*Dashboard/aptest*/
Route::set('aptest', function() {
View::make('App/aptest');
});

 


 

 
/*files/sql/insert/ooo*/
Route::set('ooo', function() {
View::make('files/sql/insert/ooo');
});

 
/*files/sql/update/ann*/
Route::set('ann', function() {
View::make('files/sql/update/ann');
});

 

 

 

 
/*Admin/admin_header*/
Route::set('admin_header', function() {
View::make('Admin/admin_header');
});

 
/*Admin/admin_footer*/
Route::set('admin_footer', function() {
View::make('Admin/admin_footer');
});

 
/*Admin/dashboard*/
Route::set('dashboard', function() {
View::make('Admin/dashboard');
});

 
/*Admin/admin_nav_top*/
Route::set('admin_nav_top', function() {
View::make('Admin/admin_nav_top');
});

 
/*Admin/admin_nav_left*/
Route::set('admin_nav_left', function() {
View::make('Admin/admin_nav_left');
});

 
/*files/sql/get/os_settings*/
Route::set('os_settings', function() {
View::make('files/sql/get/os_settings');
});

