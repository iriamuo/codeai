<?php

// إعدادات الاتصال بقاعدة البيانات
class Database {
    private static $instance = null; // كائن قاعدة البيانات الوحيد
    private $connection; // الاتصال الفعلي بقاعدة البيانات

    // إعدادات قاعدة البيانات
    private $DBHOST = "localhost";
    private $DBUSER = "foxlivra_data";
    private $DBNAME = "foxlivra_data";
    private $DBPASSWORD = "M^TN3hQqQ.up";

    // تأكد من أن الـ constructor ليس قابل للوصول مباشرةً من خارج الكلاس
    private function __construct() {
        // إعدادات الاتصال
        $dsn = "mysql:host=" . $this->DBHOST . ";dbname=" . $this->DBNAME . ";charset=utf8";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // تحسين التعامل مع الأخطاء
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // إعدادات جلب البيانات
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8', // التأكد من التشفير
        ];

        try {
            $this->connection = new PDO($dsn, $this->DBUSER, $this->DBPASSWORD, $options);
        } catch (PDOException $e) {
            die('فشل الاتصال بقاعدة البيانات: ' . $e->getMessage());
        }
    }

    // الحصول على الاتصال الوحيد
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database(); // إنشاء الاتصال لأول مرة
        }
        return self::$instance->connection; // إرجاع الاتصال
    }

    // إغلاق الاتصال بشكل آمن
    public function __destruct() {
        $this->connection = null; // إزالة الاتصال عند إنهاء التطبيق
    }
}

// استرجاع الاتصال في أي مكان داخل التطبيق
$con = Database::getInstance();

// دالة مساعدة لجلب الملفات من النظام
if (!function_exists('get_file')) {
    function get_file($dir) {
        $filePath = $_SERVER['DOCUMENT_ROOT'] . BASEDIR . 'application/views/default/' . $dir . '.php';
        
        if (file_exists($filePath)) {
            require $filePath;
        } else {
            echo "Error: File '$dir.php' not found!";
        }
    }
}

?>
