


<!--end::Header-->
<!--begin::Sidebar-->
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
<!--begin::Sidebar Brand-->
<div class="sidebar-brand">
<!--begin::Brand Link-->
<a href="./index.html" class="brand-link">
<!--begin::Brand Image-->
<img
src="themes/assets/img/AdminLTELogo.png"
alt="AdminLTE Logo"
class="brand-image opacity-75 shadow"
/>
<!--end::Brand Image-->
<!--begin::Brand Text-->
<span class="brand-text fw-light">Fox</span>
<!--end::Brand Text-->
</a>
<!--end::Brand Link-->
</div>
<!--end::Sidebar Brand-->
<!--begin::Sidebar Wrapper-->
<div class="sidebar-wrapper">
<nav class="mt-2">
<!--begin::Sidebar Menu-->




<ul
class="nav sidebar-menu flex-column"
data-lte-toggle="treeview"
role="menu"
data-accordion="false"
>







<li class="nav-item menu-open">
<a href="dashboard" class="nav-link active">
<i class="nav-icon bi bi-speedometer"></i>
<p>Dashboard</p>
</a>
</li>





<li class="nav-item">
<a href="#" class="nav-link">
<i class="nav-icon bi bi-box2"></i>
<p>
Colis
<i class="nav-arrow bi bi-chevron-right"></i>
</p>
</a>
<ul class="nav nav-treeview">


<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>tout</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>livré</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>en cours de livraison</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Annulé</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Refusé</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Relancé</p>
</a>
</li>

<li class="nav-item">
<a href="orders?state=0" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Changement de adresse</p>
</a>
</li>



</ul>
</li>







<li class="nav-item">
<a href="pickup" class="nav-link">
<i class="nav-icon bi bi-truck"></i>
<p>Bon Ramassage</p>
</a>
</li>






<li class="nav-item">
<a href="invoice" class="nav-link">
<i class="nav-icon bi bi-cash"></i>
<p>Facture Client</p>
</a>
</li>





<li class="nav-item">
<a href="invoice" class="nav-link">
<i class="nav-icon bi bi-cash"></i>
<p>Facture Livreur</p>
</a>
</li>





<li class="nav-item">
<a href="outLogUser" class="nav-link">
<i class="nav-icon bi bi-arrow-clockwise"></i>
<p>Bon de retour Livreur</p>
</a>
</li>




<li class="nav-item">
<a href="outLogUser" class="nav-link">
<i class="nav-icon bi bi-arrow-clockwise"></i>
<p>Bon de retour Client</p>
</a>
</li>




<li class="nav-item">
<a href="" class="nav-link">
<i class="nav-icon bi bi-pin-map"></i>
<p>Expédition</p>
</a>
</li>





<li class="nav-item">
<a href="" class="nav-link">
<i class="nav-icon bi bi-boxes"></i>
<p>Stock</p>
</a>
</li>






<li class="nav-item">
<a href="" class="nav-link">
<i class="nav-icon bi bi-currency-euro"></i>
<p>Tarif</p>
</a>
</li>














<li class="nav-item">
<a  class="nav-link">
<i class="nav-icon bi bi-people"></i>
<p>
Utilisateurs
<i class="nav-arrow bi bi-chevron-right"></i>
</p>
</a>
<ul class="nav nav-treeview">


<li class="nav-item">
<a href="users?rank=user" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Clients</p>
</a>
</li>



<li class="nav-item">
<a href="users?rank=delivery" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Livreurs</p>
</a>
</li>



<li class="nav-item">
<a href="users?rank=delivery" class="nav-link">
<i class="nav-icon bi bi-circle"></i>
<p>Agences</p>
</a>
</li>






</ul>
</li>



















</ul>
<!--end::Sidebar Menu-->
</nav>
</div>
<!--end::Sidebar Wrapper-->
</aside>
<!--end::Sidebar-->
<!--begin::App Main-->


