<?php 

$howz = new Bootstrap(); $howz->runBootstrap(); 

$go = "hi abdelouahed !";
print $go;
?>

ooo